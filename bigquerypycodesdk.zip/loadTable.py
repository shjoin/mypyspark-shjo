#$env:GOOGLE_APPLICATION_CREDENTIALS="C:\github\mypyspark-shjo\gcp_poc\BQ\BQ_PROJECT_WORK\withPy_BQ\mydatabricksproject-ee084f92fdc7.json"
#Running fine with SDK


def load_table_Append_csv(table_id): 
    from google.cloud import bigquery
     # Construct a BigQuery client object.
    client = bigquery.Client()
    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("Date_time", "DATETIME"),
            bigquery.SchemaField("Age", "INT64"),
            bigquery.SchemaField("Gender", "STRING"),
            bigquery.SchemaField("Country", "STRING"),
            bigquery.SchemaField("state", "STRING"),         
            bigquery.SchemaField("family_history", "STRING"),
            bigquery.SchemaField("treatment", "STRING"),
            bigquery.SchemaField("work_interfere", "STRING"),
            bigquery.SchemaField("MinIncome", "FLOAT64"),
         
        ],
       ) 
        
    job_config = bigquery.LoadJobConfig(
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,        
    )
        
    uri = "gs://source-data-bucket-shjo/sample_data.csv"
        
        
    load_job = client.load_table_from_uri(
        uri, table_id, job_config=job_config
    )  # Make an API request.

    load_job.result()  # Waits for the job to complete.
    destination_table = client.get_table(table_id)  # Make an API request.
    print("Loaded {} rows.".format(destination_table.num_rows))


def load_table_Append_table(table_id): 
    from google.cloud import bigquery
     # Construct a BigQuery client object.
    client = bigquery.Client()
    query = """
        SELECT Gender,
        SUM(MinIncome) as SUM_MinIncome
        FROM `mydatabricksproject.bq_dataset.sample` GROUP BY Gender
    """
    query_job= client.query(query)
    print("the query data:")
    for row in query_job:
        print("Gender={}, SUM_MinIncome={}".format(row[0],row["SUM_MinIncome"]))



if "__name__ == __main__":
  print('Hello,We are in Home(loadTable.py)')
  table_id='mydatabricksproject.bq_dataset.sample'
  #load_table_Append_csv(table_id)
  load_table_Append_table(table_id)