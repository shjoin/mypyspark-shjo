from pyspark.sql import SparkSession

if __name__ == "__main__":  
    spark = SparkSession \
        .builder \
        .config('spark.jars', 'gs://spark-lib/bigquery/spark-3.1-bigquery-0.27.1-preview.jar')\
        .appName("GCP_SPARK") \
        .getOrCreate()
    spark.conf.set("temporaryGcsBucket", "temp_spark-bigquery-connector")    
    #uri_notbook="gs://dataproc-staging-us-west1-968551808907-res5qpsw/notebooks/jupyter/sample.csv"
    surveyDF=spark.read \
          .option("header", "true") \
          .option("inferSchema", "true") \
          .csv("gs://dataproc-staging-us-west1-968551808907-res5qpsw/notebooks/jupyter/sample.csv")
    surveyDF.createOrReplaceTempView("survey_tbl")
    countDF = spark.sql("select Country, count(1) as count from survey_tbl where Age>=35 group by Country")
    #gcs_bucket = "gs://temp_spark-bigquery-connector"
    #bucket="gs://dataproc-staging-us-west1-968551808907-res5qpsw"
    countDF.write.format('bigquery').option('table', 'mydatabricksproject.bq_dataset.sample_country_cnt').mode("overwrite").save()