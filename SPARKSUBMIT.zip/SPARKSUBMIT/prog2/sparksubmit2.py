from pyspark.sql import SparkSession
from google.cloud import bigquery

if __name__ == "__main__":  
    spark = SparkSession \
        .builder \
        .config('spark.jars', 'gs://spark-lib/bigquery/spark-3.1-bigquery-0.27.1-preview.jar')\
        .appName("GCP_SPARK") \
        .getOrCreate()
    spark.conf.set("temporaryGcsBucket", "temp_spark-bigquery-connector")    
    
    surveyDF=spark.read \
          .option("header", "true") \
          .option("inferSchema", "true") \
          .csv("gs://dataproc-staging-us-west1-968551808907-res5qpsw/notebooks/jupyter/sample.csv")
    # sample.csv Data in this file --> Date_time	,Age	,Gender	,Country	,state	family_history	treatment	work_interfere	MinIncome 
    surveyDF.createOrReplaceTempView("survey_tbl")
    countDF = spark.sql("select Country, sum(MinIncome) as sum_MinIncome from survey_tbl group by Country")
    v_tablename ='mydatabricksproject.bq_dataset.sample_country_MinIncome'
    v_createtb = "Create table " +v_tablename+" \
                    Select Gender,\
                    T_MinIncome as sum_MinIncome \ 
                    from mydatabricksproject.bq_dataset.sample_agg"
    query_job =client.query(v_createtb)
    rows = query_job.result()