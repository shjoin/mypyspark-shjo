from pyspark.sql import SparkSession
from google.cloud import bigquery

if __name__ == "__main__":  
    spark = SparkSession \
        .builder \
        .config('spark.jars', 'gs://spark-lib/bigquery/spark-3.1-bigquery-0.27.1-preview.jar')\
        .appName("GCP_SPARK") \
        .getOrCreate()
    spark.conf.set("temporaryGcsBucket", "temp_spark-bigquery-connector")
    file="gs://dataproc-staging-us-west1-968551808907-res5qpsw/notebooks/jupyter/sample.csv"
    v_tablename ='mydatabricksproject.bq_dataset.sample_country_MinIncome'
    client = bigquery.Client()
    job_config = bigquery.LoadJobConfig(
    schema=[
        bigquery.SchemaField("Country", "STRING"),
        bigquery.SchemaField("sum_MinIncome", "INT64"),
        ]
    table = bigquery.Table(v_tablename, schema=schema)
    table = client.create_table(table)  # Make an API request.
    print("Created table {}.{}.{}".format(table.project, table.dataset_id, table.table_id))
    