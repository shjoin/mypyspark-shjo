from pyspark.sql import SparkSession
from google.cloud import bigquery

if __name__ == "__main__":  
    spark = SparkSession \
        .builder \
        .config('spark.jars', 'gs://spark-lib/bigquery/spark-3.1-bigquery-0.27.1-preview.jar')\
        .appName("GCP_SPARK") \
        .getOrCreate()
    spark.conf.set("temporaryGcsBucket", "temp_spark-bigquery-connector")
    file="gs://dataproc-staging-us-west1-968551808907-res5qpsw/notebooks/jupyter/sample.csv"
    v_tablename ='mydatabricksproject.bq_dataset.sample_country_MinIncome'
    client = bigquery.Client()
    job_config = bigquery.LoadJobConfig(
    schema=[
        bigquery.SchemaField("Date_time", "DATETIME"),
        bigquery.SchemaField("Age", "INT64"),
        bigquery.SchemaField("Gender", "STRING"),
        bigquery.SchemaField("Country", "STRING"),
        bigquery.SchemaField("state", "STRING"),
        bigquery.SchemaField("family_history", "STRING"),
        bigquery.SchemaField("treatment", "STRING"),
        bigquery.SchemaField("work_interfere", "STRING"),
        bigquery.SchemaField("MinIncome", "INT64"),        
        ],
       source_format=bigquery.SourceFormat.CSV,
    )   
    load_job = client.load_table_from_uri(file, v_tablename, job_config=job_config)  # Make an API request.

    load_job.result()  # Waits for the job to complete.

    destination_table = client.get_table(table_id)  # Make an API request.
    print("Loaded {} rows.".format(destination_table.num_rows))   
    