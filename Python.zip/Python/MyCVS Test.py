my_dict={'fruit':'apple','animal':'fox',1:'one','two':2}
my_dict2={'a':200,'b':400,'c':'qwer'}
print(my_dict2['c'])
vals={}
print(type(vals))
vals['dev1_pols']=10
print(type(vals))

vals['dev2_pols']={1:12321}
print(type(vals))
print(vals)