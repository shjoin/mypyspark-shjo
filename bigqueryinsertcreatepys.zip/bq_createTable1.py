    #def create_table(table_id: str) -> None: 
from google.cloud import bigquery

# Construct a BigQuery client object.
client = bigquery.Client()

# TODO(developer): Set table_id to the ID of the table to create.
# table_id = "your-project.your_dataset.your_table_name"

schema = [
            bigquery.SchemaField("Date_time", "DATETIME"),
            bigquery.SchemaField("Age", "INT64"),
            bigquery.SchemaField("Gender", "STRING"),
            bigquery.SchemaField("Country", "STRING"),
            bigquery.SchemaField("state", "STRING"),         
            bigquery.SchemaField("family_history", "STRING"),
            bigquery.SchemaField("treatment", "STRING"),
            bigquery.SchemaField("work_interfere", "STRING"),
            bigquery.SchemaField("MinIncome", "FLOAT64"),            
        ##bigquery.SchemaField("full_name", "STRING", mode="REQUIRED"),
        ##bigquery.SchemaField("age", "INTEGER", mode="REQUIRED"),
    ]

project_id='mydatabricksproject'
destination_dataset_id='bq_dataset'
destination_table_id='sample_country_MinIncome_test4'
table_id=project_id+'.'+destination_dataset_id+'.'+destination_table_id

table = bigquery.Table(table_id, schema=schema)
table = client.create_table(table)  # Make an API request.
print(
        "Created table {}.{}.{}".format(table.project, table.dataset_id, table.table_id)
    )
    # [END bigquery_create_table]