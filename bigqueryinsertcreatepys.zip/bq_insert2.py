
print("***************Process Being Started** *************")
try:
    from google.cloud import bigquery
    from datetime import datetime    
    client = bigquery.Client()
    now=datetime.now()
    current_time=now.strftime("%Y-%m-%d %H:%M:%S")
    upd_load_log_key=now.strftime("%Y%m%d%H%M%S")
    print("************* Start time:{}*************".format(current_time))
    project_id='mydatabricksproject'
    destination_dataset_id='bq_dataset'
    destination_table_id='sample_country_MinIncome_test4'
    dest_table_id=project_id+'.'+destination_dataset_id+'.'+destination_table_id

    source_table='sample'
    source_table_id=project_id+'.'+destination_dataset_id+'.'+source_table

    commit_sql="COMMIT TRANSACTION;"
    v_gender='Female'

    print("************* Deleting data from:{} ************* ".format(dest_table_id))
    del_sql="DELETE " +dest_table_id + " WHERE 1=1"
     
    query_job1 = client.query(del_sql)
    rows=query_job1.result()#waits for query to completed
    query_job2 = client.query(commit_sql)
    
    print("************* Now Inserting data Into:{} ************* ".format(dest_table_id))
    sql_insert="INSERT INTO "+dest_table_id+" (\
        Date_time,\
        Age,\
        Gender,\
        Country,\
        state,\
        family_history,\
        treatment,\
        work_interfere,\
        MinIncome\
        )\
        Select \
        Date_time,\
        Age,\
        Gender,\
        Country,\
        state,\
        family_history,\
        treatment,\
        work_interfere,\
        MinIncome \
        FROM " + source_table_id + "\
        WHERE \
        upper(Gender) = upper('"+ v_gender +"');"   

    query_job3 = client.query(sql_insert)    
   
    rows=query_job3.result()#waits for query to completed
    query_job4 = client.query(commit_sql)   
    print("Successfully Completed....")
except Exception as e:
     print(e)


#print("Created table {}.{}.{}".format(table.project, table.dataset_id, table.table_id)   )
