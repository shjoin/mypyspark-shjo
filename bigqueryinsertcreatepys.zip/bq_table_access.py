import os
from google.cloud import bigquery


os.environ['GOGLE_APPLICATION_CREDENTIALS'] ='C:/github/mypyspark-shjo/gcp_poc/BQ/BQ_ServiceAccountKEYJSON/mydatabricksproject-serviceaccount.json'
client=bigquery.Client()

sql_query =""" SELECT   Country,SUM(MinIncome)
               FROM `mydatabricksproject.bq_dataset.sample` 
               GROUP BY Gender,Country
            """  

query_job=client.query(sql_query)
for row in query_job.result():
    print(row)
