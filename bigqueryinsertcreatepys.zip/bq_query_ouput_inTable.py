import os
import time
from google.cloud import bigquery

#os.environ['GOGLE_APPLICATION_CREDENTIALS'] ='C:/github/mypyspark-shjo/gcp_poc/BQ/BQ_ServiceAccountKEYJSON/mydatabricksproject-serviceaccount.json'
client=bigquery.Client()

sql_query = """
        select Country, sum(MinIncome) as sum_MinIncome 
        FROM `mydatabricksproject.bq_dataset.sample` 
        group by Country
        """
    
project_id='mydatabricksproject'
destination_dataset_id='bq_dataset'
destination_table_id='sample_country_MinIncome_test3'
'''    
    #Construct destination table reference
destination_dataset_ref=client.dataset(destination_dataset_id,project_id)
destination_dataset=client.get_dataset(destination_dataset_ref)
    
destination_table_ref=destination_dataset_ref.table(destination_table_id)
    
    #query job configuration
query_job_config =bigquery.QueryJobConfig()
query_job_config.destination=destination_dataset_ref
query_job =client.query(sql_query,location=destination_dataset.location,job_config=query_job_config)
'''
# OR 
table_id2=project_id+'.'+destination_dataset_id+'.'+destination_table_id
job_config2 = bigquery.QueryJobConfig(destination=table_id2)
query_job =client.query(sql_query,job_config=job_config2)
print('working1 .....')

    #run the SQl 
    #   #waiting for the job to complete 
while query_job.state != 'DONE':    
    time.sleep(3)
    query_job.reload()
print(f'Query result is saved to {destination_dataset_id}.{destination_table_id}')    


'''
working1 .....
Query result is saved to bq_dataset.sample_country_MinIncome_test2
'''