#created By Shailendra joshi
import subprocess
import datetime


def main():
        print('Starts ......')
        PYname='dtmk079'
        function = 'prc_ins_ft_pot_remit_summary'
        IBS_SUCCESS_GROUP='shailendra.joshi@meredith.com'
        STMT = "pkg_pot_remit_dm.prc_ins_ft_pot_remit_summary(500," + "'" + PYname + "'" + ",'" + function + "'"+ ")"
             #select * from dtm.ft_pot_remit_daily_summary where trunc(create_date)=trunc(sysdate);alter table ft_pot_remit_daily_summary modify create_by varchar2(9);
        connstring = 'dtm/$dtm123@syndwd:1591/SYNDW.INT.SYNAPSEGROUPINC.COM'
        HOME = '/home1/syndw'
        SCHEMA='dtm'
        #sqlpluspath = 'C:/Oracle/app/client/product/12.1.0/client_64bit/BIN/sqlplus.exe'
        sqlscript = HOME + '/' + SCHEMA + '/' +'sql' + '/'+ 'dtms001.sql'
        print(sqlscript, 'date: ',datetime.datetime.now().strftime("%Y-%m-%d") + '_' + datetime.datetime.now().strftime("%H:%M:%S"))
        print("**********************************************************************************************")
        print(STMT)
        print("**********************************************************************************************")
        #sqlstringSP = sqlpluspath + ' -l' ' -s ' + GV_WALLET_USER + '  @' + sqlscript + GV_SCHEMA + STMT # for wallet
        #sqlstringSP = $ORACLE_HOME  + '/bin/sqlplus' + ' -l' ' -s ' + connstring + '  @' + sqlscript + ' ' + SCHEMA + ' ' + STMT
        #sqlstringSP = '/oracle/app/oracle/product/12.1.0/client_1/bin/sqlplus -l -s ' + connstring + '  @' + sqlscript + ' ' + SCHEMA + ' ' + STMT        
        #sqlstringSP = $ORACLE_HOME/bin/sqlplus/bin/sqlplus -l -s  + ' /@SYNDWD_DTM' + '  @' + sqlscript + ' ' + SCHEMA + ' ' + STMT
        
        #sqlstringSP = '/oracle/app/oracle/product/12.1.0/client_1/bin/sqlplus -l -s ' + '/@SYNDWD_DTM' + '  @' + sqlscript + ' ' + SCHEMA + ' ' + '"' + STMT + '"' # working fine
        sqlstringSP = '$ORACLE_HOME/bin/sqlplus -l -s ' + '/@SYNDWD_DTM' + '  @' + sqlscript + ' ' + SCHEMA + ' ' + '"' + STMT + '"' # working fine        

        sp = subprocess.Popen(sqlstringSP, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print('Running Now .. ', sqlstringSP)
        rc = sp.wait()
        print("Sctipt Executed ")
        o, e = sp.communicate()
        print("RUN END  ")
        stdout_lines_out = o.decode('utf-8').splitlines()
        for line in stdout_lines_out:           
            print( line)
        stdout_lines_err = e.decode('utf-8').splitlines()
        for line in stdout_lines_err:            
            print(line)    


if __name__ == "__main__":
    print('main Starts ......')
    main()
    print("****DONE MAIN****")