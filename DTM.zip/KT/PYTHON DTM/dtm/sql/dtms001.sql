-- ***************************************************************
-- Name:            dtms001.sql
-- Written By:      Kristen Markarian
-- Date:            04/23/2014
-- Description:     execute procedures in DWHSTG for Line Items and Cancels
--
-- Calling Program: dtmk001.ksh
--
-- Modifications:
-- Date         Name            Description
-- --------     -------------   ----------------------------
-- 04/23/2014   KMarkarian      created
-- 10/12/2016   Jonathan Smith  removed the "PROMPT Populate DMT tables" to make more generic and reusable
-- ***************************************************************
set concat ~
set blockterminator ~ 
set echo on
set feedback off
set verify off
set serveroutput on size 1000000 
set heading off
set pagesize 1000
set linesize 200
set term on
set timing on
set time on
set trimspool ON
show user

WHENEVER SQLERROR EXIT 1  ROLLBACK;
WHENEVER SQLERROR exit 1 rollback; 

DEFINE user=&1;
DEFINE stmt=&2;

alter session set current_schema=&user;

EXEC &stmt;

commit;

EXIT 0;
