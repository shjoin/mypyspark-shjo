#default values will be used in all environments

HOME = '/home1/syndw/Python-3.9.4/py'
SQLPLUS = '$ORACLE_HOME/bin/sqlplus'
GV_ERROR =0
GV_LOGname=''
GV_EMAIL_SUBJECT=''
GV_SEND_MAIL=''
IBS_SUCCESS_GROUP='shailendra.joshi@meredith.com'
GV_EMAIL_GROUP =IBS_SUCCESS_GROUP
GV_SEND_LOG_FILE = ''
GV_EXIT_FLAG=''
PYname=''