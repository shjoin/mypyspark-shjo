import sys,os
import logging, socket
import datetime 
import runsqlplus_SP
import util
import arguments
import config


def main():
        # parse command line arguments and save them to args
        print('Starts ......')
        args = arguments.get_arguments(sys.argv)
        print('Parameters: ', args.WALLET,args.SCHEMA,args.DBENV,args.first_step,args.last_step)       #   SYNDWD_DTMTM DTM dtm
        GV_CURRENT_STEP="STEP000"
        GV_RESTART_STEP="STEP000"
        GV_CONNECTION_TYPE = "WALLET"
        config.GV_ERROR = 0
        GV_WALLET = args.WALLET
        GV_LAST_STEP=args.last_step
        GV_SCHEMA = args.SCHEMA # convert into lower case 
        GV_ENV=args.DBENV
        sqlpluspath = config.SQLPLUS #'$ORACLE_HOME/bin/sqlplus'
        config.PYname=os.path.basename(__file__)
        IBS_SUCCESS_GROUP='shailendra.joshi@meredith.com'
        config.GV_SEND_MAIL = "Y"  # Y/N | If a batch process; always N
        config.GV_EMAIL_GROUP =IBS_SUCCESS_GROUP  # where should the emails go to
        config.GV_EMAIL_SUBJECT = config.PYname  # description/KSHname
        config.GV_SEND_LOG_FILE = "Y"  # Y
        config.GV_EXIT_FLAG = "Y"  # Y/N
        GV_HOME = config.HOME #'/home1/syndw/Python-3.9.4/py'
        log_file = GV_HOME + '/' + GV_SCHEMA + '/log/' + config.PYname+'_' + datetime.datetime.now().strftime("%m%d%y") + '-' + datetime.datetime.now().strftime(
            "%H%M%S") + '.log'
        logging.basicConfig(level=logging.INFO,
                            format='%(message)s',
                            datefmt='%m-%d %H:%M',
                            filename=log_file,
                            filemode='w')
        config.GV_LOGname=log_file
        #logging.info("********************************")

       # PYpath = GV_HOME + '/' + GV_SCHEMA + '/' + 'py' #'/home1/syndw/Python-3.9.4/py/dtm/py'
        hostname = socket.gethostname()

        if args.first_step != None:
           GV_RESTART_STEP = args.first_step
           GV_NEXT_STEP=args.first_step
        elif args.first_step == None:
             GV_NEXT_STEP ='STEP010'

        while GV_NEXT_STEP!= 'LASTSTEP':
          if GV_NEXT_STEP == 'STEP010':
             GV_CURRENT_STEP = 'STEP010'
             GV_RESTART_STEP = 'STEP010'
             STMT = "pkg_pot_remit_dm.prc_ins_ft_pot_remit_summary(500," + "'" + config.PYname + "'" + ",'prc_ins_ft_pot_remit_summary')"
             #select * from dtm.ft_pot_remit_daily_summary where trunc(create_date)=trunc(sysdate);alter table ft_pot_remit_daily_summary modify create_by varchar2(9);
             
            # connstring = 'dtm/$dtm123@syndwd:1591/SYNDW.INT.SYNAPSEGROUPINC.COM'

             sqlscript = GV_HOME + '/' + args.SCHEMA + '/' +'sql' + '/'+ 'dtms001.sql'
             config.GV_ERROR,Errcode = util.chk_file_exists(sqlscript, IBS_SUCCESS_GROUP, config.PYname,
                                          GV_CURRENT_STEP)  # need to check the file exists ort not and all fies should be not null
             if config.GV_ERROR == 1:
                 print('Error out')
                 logging.info(Errcode)
                 sys.exit()

             logging.info('******************************************************************************')
             logging.info('%s' % GV_CURRENT_STEP + ' : %s' % sqlscript + ' date %s ' % datetime.datetime.now().strftime(  "%Y-%m-%d") + '-%s' % datetime.datetime.now().strftime("%H:%M:%S"))
             print(GV_CURRENT_STEP, ' : ', sqlscript, 'date: ',datetime.datetime.now().strftime("%Y-%m-%d") + '_' + datetime.datetime.now().strftime("%H:%M:%S"))
             print("**********************************************************************************************")

             logging.info('%s' % STMT)
             logging.info('******************************************************************************')
             logging.info('%s' % sqlpluspath + ' -l' ' -s ' + '  @%s' % sqlscript + ' %s ' % GV_SCHEMA )
             print(STMT)
             print("**********************************************************************************************")

             sqlstringSP = sqlpluspath + ' -l' ' -s ' + '/@' + GV_WALLET + '  @' + sqlscript +' ' + GV_SCHEMA + ' ' + '"' +  STMT + '"'  # for wallet
             #sqlstringSP = '$ORACLE_HOME/bin/sqlplus -l -s ' + '/@SYNDWD_DTM' + '  @' + sqlscript + ' ' + SCHEMA + ' ' + '"' + STMT + '"' # working fine   
             #sqlstringSP = sqlpluspath + ' -l' ' -s ' + connstring + '  @' + sqlscript + ' ' + GV_SCHEMA + ' ' + STMT
             o, e = runsqlplus_SP.runSqlPlusQuery_SP(args.DBENV, sqlstringSP,'nothing')
             stdout_lines_out = o.decode('utf-8').splitlines()
             for line in stdout_lines_out:
                 logging.info('%s'% line)
                 print( line)

             stdout_lines_err = e.decode('utf-8').splitlines()
             for line in stdout_lines_err:
                 logging.info('%s'%line)
                 print(line)

             if GV_NEXT_STEP == GV_LAST_STEP:
                GV_NEXT_STEP = 'LASTSTEP'
             elif GV_NEXT_STEP != GV_LAST_STEP:
                  GV_NEXT_STEP = 'STEP020' # need to add new step
                  #print("****NEXT is last step****")
          util.err_chk()

# STEP020
          if GV_NEXT_STEP == 'STEP020':
             GV_CURRENT_STEP = 'STEP020'
             GV_RESTART_STEP = 'STEP020'
             STMT = "pkg_pot_remit_dm.prc_ins_ft_pot_remit_trueup_summary(500," + "'" + config.PYname + "'" + ",'prc_ins_ft_pot_remit_trueup_summary')"          
             connstring = 'dtm/$dtm123@syndwd:1591/SYNDW.INT.SYNAPSEGROUPINC.COM'

             sqlscript = GV_HOME + '/' + args.SCHEMA + '/' +'sql' + '/'+ 'dtms001.sql'
             
             Error,Errcode = util.chk_file_exists(sqlscript, IBS_SUCCESS_GROUP, config.PYname,
                                          GV_CURRENT_STEP)  # need to check the file exists ort not and all fies should be not null
             if Error == 1:
                 print('Error out')
                 logging.info(Errcode)
                 sys.exit()

             logging.info('******************************************************************************')
             logging.info('%s' % GV_CURRENT_STEP + ' : %s' % sqlscript + ' date %s ' % datetime.datetime.now().strftime(  "%Y-%m-%d") + '-%s' % datetime.datetime.now().strftime("%H:%M:%S"))
             print(GV_CURRENT_STEP, ' : ', sqlscript, 'date: ',datetime.datetime.now().strftime("%Y-%m-%d") + '_' + datetime.datetime.now().strftime("%H:%M:%S"))
             print("**********************************************************************************************")

             logging.info('%s' % STMT)
             logging.info('******************************************************************************')
             logging.info('%s' % sqlpluspath + ' -l' ' -s ' + '  @%s' % sqlscript + ' %s ' % GV_SCHEMA )
             print(STMT)
             print("**********************************************************************************************")

             #sqlstringSP = sqlpluspath + ' -l' ' -s ' + GV_WALLET_USER + '  @' + sqlscript + GV_SCHEMA + STMT # for wallet
             #sqlstringSP = sqlpluspath + ' -l' ' -s ' + connstring + '  @' + sqlscript + ' ' + GV_SCHEMA + ' ' + STMT
             sqlstringSP = sqlpluspath + ' -l' ' -s ' + '/@' + GV_WALLET + '  @' + sqlscript +' ' + GV_SCHEMA + ' ' + '"' +  STMT + '"'  # for wallet
             o, e = runsqlplus_SP.runSqlPlusQuery_SP(args.DBENV, sqlstringSP,'nothing')
             stdout_lines_out = o.decode('utf-8').splitlines()
             for line in stdout_lines_out:
                 logging.info('%s'% line)
                 print(line)

             stdout_lines_err = e.decode('utf-8').splitlines()
             for line in stdout_lines_err:
                 logging.info('%s'%line)
                 print(line)

             if GV_NEXT_STEP == GV_LAST_STEP:
                GV_NEXT_STEP = 'LASTSTEP'
             elif GV_NEXT_STEP != GV_LAST_STEP:
                  GV_NEXT_STEP = 'LASTSTEP' # need to add new step
                  print("****NEXT is last step****")
          util.err_chk()
        # Exit Script with Exit 0
        print(" ")
        print("******************************************************************************" )
        print( "**** SUCCESS: " + config.PYname + " HAS COMPLETED SUCCESSFULLY! ***")
        print( "******************************************************************************")
        logging.info('******************************************************************************')
        logging.info('**** SUCCESS: %s' % config.PYname + ' HAS COMPLETED SUCCESSFULLY! ***')
        logging.info('******************************************************************************')
        logging.shutdown()

if __name__ == "__main__":
    print('main Starts ......')
    main()
    print("****DONE MAIN****")