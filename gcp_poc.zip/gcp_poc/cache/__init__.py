#-- this __init__ file has the code for initialization some default values for you project.
import logging
import os

print ('this __init__ file has the code for initialization some default values for you project (from __int__.py . ')

def check_env_vars(self) -> bool:
        require_env_vars =['sql_connection','any_key','token_url']
        for var in require_env_vars:
            if var not in os.environ:
                logging.error('Missing env varriables - %s',var)
                return False
        return True





