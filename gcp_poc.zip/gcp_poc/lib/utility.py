import logging
import configparser
from pyspark import SparkConf

class Gcp_spark():
    # class attribute should not be changed  but we can change outside the class
    var_1 = "initialization from Class Gcp_spark"
    var_count = 1
    print(var_1)
    logger = logging.Logger(__name__)

    def __init__(self, Pname, projectname):  # Constructor Method,by default it will call when we create a object
        self.program_name = Pname
        self.project_name = projectname
        Gcp_spark.var_count += 1
        print('Prgram name: ' + self.program_name + "project Name : " + self.project_name + ' Count ?: ' , Gcp_spark.var_count )

    def read_csv_df(self,spark, data_file):
        return spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv(data_file)

    def count_by_country(self,survey_df):
        return survey_df.filter("Age < 70") \
            .select("Age", "Gender", "Country", "state") \
            .groupBy("Country") \
            .count()

    def get_spark_app_config(self):
        spark_conf = SparkConf()
        config = configparser.ConfigParser()
        config.read("spark.conf")

        for (key, val) in config.items("SPARK_APP_CONFIGS"):
            spark_conf.set(key, val)
            logging.info('Spark config created ')
        return spark_conf


class Gcp_spark_2(Gcp_spark):
    def function_1(self):
       print('inherited the Gcp_spark in Gcp_spark_2')
       logging.info('inherited the Gcp_spark in Gcp_spark_2')

