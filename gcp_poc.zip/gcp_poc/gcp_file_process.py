from lib.utility import *
from pyspark.sql import *
from pyspark.sql import SparkSession
import cache

if __name__ == "__main__":
    execution_obj = Gcp_spark('dataprocess','gcp_spark')
    confobj = execution_obj.get_spark_app_config()

    # Or spark = SparkSession \
    #         .builder \
    #         .master("local[3]") \
    #         .appName("GCP_SPARK") \
    #         .getOrCreate()

    spark = SparkSession.builder \
            .config(conf=confobj) \
            .getOrCreate()
    conf_out = spark.sparkContext.getConf()

    surveyDF=execution_obj.read_csv_df(spark,'C:/github/mypyspark-shjo/gcp_poc/data/sample.csv')
    surveyDF.createOrReplaceTempView("survey_tbl")
    countDF = spark.sql("select Country, count(1) as count from survey_tbl where Age<40 group by Country")
    countDF.show()
    countDF2=execution_obj.count_by_country(surveyDF)
    countDF2.show()

    execution_obj2=Gcp_spark_2('dataExtract','gcp_pyspark')



